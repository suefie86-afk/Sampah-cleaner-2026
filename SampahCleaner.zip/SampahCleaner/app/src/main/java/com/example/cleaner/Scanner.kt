package com.example.cleaner

import java.io.File
import java.security.MessageDigest

data class ScanResult(
    val junk: List<File> = emptyList(),
    val large: List<File> = emptyList(),
    val dupes: List<File> = emptyList(),
) {
    fun without(paths: Set<String>) = ScanResult(
        junk.filterNot { it.path in paths },
        large.filterNot { it.path in paths },
        dupes.filterNot { it.path in paths },
    )
}

object Scanner {
    private val junkExt = setOf("tmp", "log", "temp", "bak", "old", "chk")
    private const val LARGE = 100L * 1024 * 1024   // 100 MB
    private const val DUPE_MIN = 1L * 1024 * 1024  // 1 MB

    fun scan(root: File): ScanResult {
        val junk = mutableListOf<File>()
        val large = mutableListOf<File>()
        val bySize = HashMap<Long, MutableList<File>>()

        root.walkTopDown()
            // Android/ tidak bisa diakses app lain, lewati saja
            .onEnter { !(it.parentFile == root && it.name.equals("Android", true)) }
            .forEach { f ->
                if (!f.isFile) return@forEach
                val len = f.length()
                val ext = f.extension.lowercase()
                val isJunk = len == 0L ||
                    ext in junkExt ||
                    (ext == "apk" && f.parentFile?.name.equals("Download", true)) ||
                    f.path.contains("/.thumbnails/")
                if (isJunk) {
                    junk += f
                } else {
                    if (len >= LARGE) large += f
                    if (len >= DUPE_MIN) bySize.getOrPut(len) { mutableListOf() } += f
                }
            }

        val dupes = mutableListOf<File>()
        for (group in bySize.values) {
            if (group.size < 2) continue
            group.mapNotNull { f -> md5(f)?.let { it to f } }
                .groupBy({ it.first }, { it.second })
                .values
                .filter { it.size > 1 }
                .forEach { same ->
                    // simpan yang paling lama, sisanya dianggap duplikat
                    dupes += same.sortedBy { it.lastModified() }.drop(1)
                }
        }

        return ScanResult(
            junk = junk.sortedByDescending { it.length() },
            large = large.sortedByDescending { it.length() },
            dupes = dupes.sortedByDescending { it.length() },
        )
    }

    private fun md5(f: File): String? = try {
        val md = MessageDigest.getInstance("MD5")
        f.inputStream().buffered().use { s ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    } catch (e: Exception) {
        null
    }
}
