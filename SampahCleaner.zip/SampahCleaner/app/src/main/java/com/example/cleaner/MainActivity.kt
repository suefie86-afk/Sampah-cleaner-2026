package com.example.cleaner

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.text.format.Formatter
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val root = remember { Environment.getExternalStorageDirectory() }

    var hasPerm by remember { mutableStateOf(Environment.isExternalStorageManager()) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        hasPerm = Environment.isExternalStorageManager()
    }

    var result by remember { mutableStateOf<ScanResult?>(null) }
    var scanning by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var confirm by remember { mutableStateOf(false) }

    fun size(b: Long) = Formatter.formatFileSize(ctx, b)

    Scaffold { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            Text("Sampah Cleaner", style = MaterialTheme.typography.headlineSmall)

            val stat = remember(result) { StatFs(root.path) }
            Text(
                "Kosong ${size(stat.availableBytes)} dari ${size(stat.totalBytes)}",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(vertical = 8.dp),
            )

            if (!hasPerm) {
                Text("Aplikasi butuh izin \"Akses semua file\" untuk memindai penyimpanan.")
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    ctx.startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:${ctx.packageName}")
                        )
                    )
                }) { Text("Beri izin") }
                return@Column
            }

            Button(
                enabled = !scanning,
                onClick = {
                    scanning = true
                    selected = emptySet()
                    scope.launch {
                        result = withContext(Dispatchers.IO) { Scanner.scan(root) }
                        scanning = false
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (scanning) "Memindai..." else "Pindai sekarang") }

            if (scanning) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))

            val r = result ?: return@Column
            val titles = listOf("Sampah", "File besar", "Duplikat")
            val lists = listOf(r.junk, r.large, r.dupes)

            TabRow(selectedTabIndex = tab, modifier = Modifier.padding(top = 8.dp)) {
                titles.forEachIndexed { i, t ->
                    Tab(
                        selected = tab == i,
                        onClick = { tab = i },
                        text = { Text("$t (${lists[i].size})", maxLines = 1) },
                    )
                }
            }

            val current = lists[tab]
            LazyColumn(Modifier.weight(1f)) {
                items(current, key = { it.path }) { f ->
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable {
                                selected = if (f.path in selected) selected - f.path else selected + f.path
                            }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = f.path in selected, onCheckedChange = null)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                f.parent ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        Text(size(f.length()), style = MaterialTheme.typography.labelMedium)
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    selected = selected + current.map { it.path }
                }, modifier = Modifier.weight(1f)) { Text("Pilih semua") }
                Button(
                    enabled = selected.isNotEmpty(),
                    onClick = { confirm = true },
                    modifier = Modifier.weight(1f),
                ) {
                    val total = selected.sumOf { File(it).length() }
                    Text("Hapus (${size(total)})")
                }
            }

            if (confirm) {
                AlertDialog(
                    onDismissRequest = { confirm = false },
                    title = { Text("Hapus ${selected.size} file?") },
                    text = { Text("File yang dihapus tidak bisa dikembalikan.") },
                    confirmButton = {
                        TextButton(onClick = {
                            confirm = false
                            val toDelete = selected
                            scope.launch {
                                withContext(Dispatchers.IO) { toDelete.forEach { File(it).delete() } }
                                result = result?.without(toDelete)
                                selected = emptySet()
                            }
                        }) { Text("Hapus") }
                    },
                    dismissButton = { TextButton(onClick = { confirm = false }) { Text("Batal") } },
                )
            }
        }
    }
}
