# Sampah Cleaner

Cara build:
1. Buka folder ini di Android Studio (Ladybug atau lebih baru), tunggu Gradle sync.
2. Colok HP (USB debugging aktif) atau pakai emulator, lalu klik Run.
3. Saat app dibuka, beri izin "Akses semua file".

Catatan: izin MANAGE_EXTERNAL_STORAGE tidak diizinkan Play Store untuk app pembersih biasa, jadi cocok untuk pemakaian pribadi (sideload).
Min Android 11 (API 30).
